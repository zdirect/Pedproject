<?php 

namespace core\user\controller;

use core\base\controllers\BaseController;

class IndexController extends BaseController{

    protected $name;

    protected function inputData(){
    
    }

  
    
}