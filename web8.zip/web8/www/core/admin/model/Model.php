<?php

namespace core\admin\model;

use core\base\model\BaseModel;

class Model extends BaseModel
{



}