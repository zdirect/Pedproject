<?php 

namespace core\admin\expansion;

use core\base\controllers\Singleton;

class TeachersExpension
{
    use Singleton;

    public function expanstion($args = []){
        exit('ok');
    }
}