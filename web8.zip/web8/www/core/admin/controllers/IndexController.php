<?php 

namespace core\admin\controllers;

use core\base\controllers\BaseController;
use core\admin\model\Model;
use core\base\settings\Settings;

class IndexController extends BaseController
{
    protected function inputData(){
        $redirect = PATH . Settings::get('routes')['admin']['alies'] . '/show';

        $this->redirect($redirect);
    }

}