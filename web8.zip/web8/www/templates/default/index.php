
<h1><?php echo $name?></h1>