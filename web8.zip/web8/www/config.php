<?php 

if (!defined('VG_ACCESS')) die;

const SITE_URL = 'http:/localhost';
const PATH = '/';

const HOST = 'database';
const DB_NAME = 'docker';
const USER = 'docker';
const PASS = 'docker';
