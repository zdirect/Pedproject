* Update japanese Readme
* Update issue templates
* php8 as soon as it is available
